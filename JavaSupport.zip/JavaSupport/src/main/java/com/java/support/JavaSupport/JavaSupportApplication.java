package com.java.support.JavaSupport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSupportApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaSupportApplication.class, args);
	}

}
