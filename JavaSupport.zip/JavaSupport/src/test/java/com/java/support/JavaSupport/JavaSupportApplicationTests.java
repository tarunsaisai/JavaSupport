package com.java.support.JavaSupport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSupportApplicationTests {

	@Test
	void contextLoads() {
	}

}
